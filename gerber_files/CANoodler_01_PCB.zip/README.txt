2-Layer PCB

Soldermask: Black
Silkscreen: White

Finish: Immersion Gold

Board Files:

 .GM1 - PCB Panel
 .GTO - Top Silkscreen
 .GTS - Top Soldermask
 .GTL - Top Copper
 .GBL - Bottom Copper
 .GBS - Bottom Soldermask
 .GBO - Bottom Silkscreen
 .XLN - Drill File


Other Files:

 .GTP - Top Paste (used for stencil)
 .GBP - Bottom Paste (NOT USED)